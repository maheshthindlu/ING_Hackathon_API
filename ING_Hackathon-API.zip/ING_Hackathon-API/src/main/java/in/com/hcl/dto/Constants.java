package in.com.hcl.dto;

public class Constants{
	
	public static final String LOGIN = "/auth/login";
	public static final String CREATE_OREDER = "/orders";
	
}